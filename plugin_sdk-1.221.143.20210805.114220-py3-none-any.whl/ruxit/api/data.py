"""
Structures for holding data gathered by plugins. They enforce types so that a plugin cannot accidentally report
a number as a string.
"""

from enum import Enum, IntEnum, unique
import typing
import ruxit.api.selectors
import time
import copy
from ruxit.utils.firewall import InternalAPI_ext, Firewall

class StatCounterDataPoint:
    """ DT_IGNORE """
    def __init__(self, min: float, max: float, sum: float, count: int):
        self._min = min
        self._max = max
        self._sum = sum
        self._count = count

    @property
    def min(self):
        return self._min

    @property
    def max(self):
        return self._max

    @property
    def sum(self):
        return self._sum

    @property
    def count(self):
        return self._count


class BaseMetric:

    PID_KEY = "rx_pid"

    def __init__(self, key, value, dimensions: typing.Dict[str, str] = {},
                 entity_selector=ruxit.api.selectors.FromPluginSelector()):
        self.key = key
        self.value = value
        self.dimensions = dimensions
        if dimensions is None:
            self.topXKey = (entity_selector, key)
            self.dimensions_key = ()
        else:
            self.topXKey = (entity_selector, key, dimensions[BaseMetric.PID_KEY]) if BaseMetric.PID_KEY in dimensions else (entity_selector, key)
            self.dimensions_key = tuple({k: v for k, v in dimensions.items() if k is not self.PID_KEY}.items())
        self.entity_selector = entity_selector
        self.measurement_time = time.monotonic()

    @property
    def key(self):
        """
        Key of the measurement. Must be a string.
        """
        return self._key

    @property
    def value(self):
        """
        Value of the measurement. Must be convertible to float.
        """
        return self._value


    @property
    def dimensions(self)->typing.Dict[str, str]:
        """
        Dimensions of the measurement. A Dictionary with string keys and string values.
        """
        return self._dimensions

    @property
    def dimensions_keys_tuple(self):
        return tuple(self._dimensions.items())

    @dimensions.setter
    def dimensions(self, dimensions: typing.Dict[str, str]):
        if dimensions:
            for key, value in dimensions.items():
                if not isinstance(key, str) or not isinstance(value, str):
                    raise TypeError("Each dimensions key, and value must be unicode object, got %s and %s instead" % (type(key), type(value)))
            self._dimensions = dimensions
        else:
            self._dimensions = {}


    def __repr__(self):
        return "%s(key=%s,value=%s,dimensions=%s,selector=%s)" % (type(self).__name__, self.key, self.value, self.dimensions, self.entity_selector)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return {k: v for k, v in self.__dict__.items() if k != "measurement_time"} == \
                   {k: v for k, v in other.__dict__.items() if k != "measurement_time"}
        return NotImplemented


class PluginMeasurement(BaseMetric):
    """
    Single plugin measurement.

    Use of this class is optional. :class:`~ruxit.api.results_builder.ResultsBuilder` exposes methods that handle this
    type directly and those that abstract them away.
    """
    def __init__(self, key: str, value: float, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: float):
        if not isinstance(value, float):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value


class PluginMeasurementStatCounter(BaseMetric):
    """
    DT_IGNORE
    PluginMeasurementStatCounter object allows sending min, max, sum and counter values instead of single plugin measurement.

    Use of this class is optional. :class:`~ruxit.api.results_builder.ResultsBuilder` exposes `add_absolute_stat_counter_result` method to send PluginMeasurementStatCounter.
    """
    def __init__(self, key: str, value: StatCounterDataPoint, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: StatCounterDataPoint):
        if not isinstance(value, StatCounterDataPoint):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value


class PluginStateMetric(BaseMetric):
    """
    State measurement.

    States are string described in plugin json as statetimeseries
    """
    def __init__(self, key: str, value: str, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: str):
        if not isinstance(key, str):
            raise TypeError("key must be an unicode object, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value):
        if isinstance(value, Enum):
            self._value = value.value
        elif not isinstance(value, str):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value


class PluginMeasurementV3(BaseMetric):
    """
    Not allowed for Custom Plugin
    """
    @InternalAPI_ext(exc_message="PluginMeasurementV3 is not allowed for Custom Plugin")
    def __init__(self, key: int, value: float, dimensions: typing.Dict[str, str]=None, entity_selector=ruxit.api.selectors.FromPluginSelector()):
        super().__init__(key, value, dimensions, entity_selector)

    @BaseMetric.key.setter
    def key(self, key: int):
        if not isinstance(key, int):
            raise TypeError("key must be an integer, got, %s instead" % type(key))
        self._key = key

    @BaseMetric.value.setter
    def value(self, value: float):
        if not isinstance(value, float):
            try:
                self._value = float(value)
            except TypeError as ex:
                raise TypeError("value must be convertable to float, got %s instead" % (type(value)))
        else:
            self._value = value
            

@unique
class MEAttribute(IntEnum):
    """
    Enumerates types of properties to report.
    """
    INTERNAL_DEBUG_PROPERTY = 1
    DOCKER_CONTAINER_PROPS = 2
    PROCESS_GROUP_TECHS = 3
    CONTRIBUTED_NAME = 4
    CUSTOM_PG_METADATA = 5
    CUSTOM_DEVICE_METADATA = 6
    CUSTOM_HOST_METADATA = 7


class PluginProperty:
    """
    A text property a plugin can gather.
    """
    __allowed_prop = frozenset([MEAttribute.PROCESS_GROUP_TECHS, MEAttribute.CONTRIBUTED_NAME,
                                MEAttribute.CUSTOM_PG_METADATA, MEAttribute.CUSTOM_HOST_METADATA])
    __custom_prop = frozenset([MEAttribute.CUSTOM_PG_METADATA, MEAttribute.CUSTOM_DEVICE_METADATA,
                               MEAttribute.CUSTOM_HOST_METADATA])

    def __init__(self, key=None, value=None, entity_selector=ruxit.api.selectors.FromPluginSelector(),
                 me_attribute=MEAttribute.INTERNAL_DEBUG_PROPERTY):
        """
        :param key: :class:`~str`: property key
        :param value: :class:`~str`: property value
        :param entity_selector: plugin's entity selector :class:`~ruxit.api.selectors.FromPluginSelector` by default
        :param me_attribute(MEAttribute): property type
        """
        self.key = key
        self.value = value
        self.entity_selector = entity_selector
        if not PluginProperty.is_allowed_for_pa(me_attribute) and not Firewall.is_allowed_call():
            raise Exception(str(me_attribute) + " property type is not allowed for custom plugins")
        self.me_attribute = me_attribute

    @classmethod
    def is_allowed_for_pa(cls, attribute:MEAttribute)->bool:
        """
        :return: true if property with attribute could be directly created from custom plugin (PA case)
        """
        return attribute in PluginProperty.__allowed_prop

    @classmethod
    def is_custom(cls, attribute:MEAttribute)->bool:
        """
        :return: true if property attribute is a custom property (with limits)
        """
        return attribute in PluginProperty.__custom_prop

    @property
    def key(self):
        """
        Key of property.
        """
        return self._key

    @key.setter
    def key(self, key):
        if key is not None and not isinstance(key, str):
            raise TypeError("key must be an unicode object or None type, got, %s instead" % type(key))
        self._key = key

    @property
    def value(self):
        """
        Value of property
        """
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, str):
            raise TypeError("value must be an unicode object or None type, got, %s instead" % type(value))
        self._value = value

    @property
    def me_attribute(self):
        """
        Property type
        """
        return self._me_attribute

    @me_attribute.setter
    def me_attribute(self, me_attribute):
        if not isinstance(me_attribute, MEAttribute):
            raise TypeError("value must be an MEAttribute object, got, %s instead" % type(me_attribute))
        self._me_attribute = me_attribute

    def __repr__(self):
        return "PluginProperty(key=%s,value=%s,selector=%s,me_attribute=%s)" % (
            self.key, self.value, self.entity_selector, self.me_attribute)


class PluginMeasurementList:
    """
    Collection of PluginMeasurements. Used internally.
    """
    def __init__(self, timestamp=None, measurements=None):
        self._timestamp = timestamp
        self._measurements = measurements

    @property
    def timestamp(self):
        """ DT_IGNORE """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        self._timestamp = None
        if timestamp:
            self._timestamp = int(timestamp)

    @property
    def measurements(self):
        """ DT_IGNORE """
        return self._measurements

    @measurements.setter
    def measurements(self, measurements):
        self._measurements = []
        if measurements:
            for m in measurements:
                if not isinstance(m, BaseMetric):
                    raise TypeError("Each measurement should be an instance of BaseMetric, got %s instead" % type(m))
            self._measurements = measurements

    @property
    def is_empty(self):
        """ DT_IGNORE """
        return len(self._measurements) == 0

    @property
    def length(self):
        """ DT_IGNORE """
        return len(self._measurements)


class PluginMeasurementStorage:

    MAX_DIMENSIONS_PER_METRIC = 1000

    def __init__(self, topx_data: typing.Dict[str, int] = {}):
        self._persistent_storage: typing.Dict[tuple, typing.Dict[tuple, typing.List[PluginMeasurement]]] = {}
        self._flat_storage = []
        self._total_storage_size = 0
        self.topx_data = topx_data
        self._overflow_info: set[str] = set()

    def store(self, pm: PluginMeasurement) -> bool:
        stored_value = self._persistent_storage.setdefault(pm.topXKey, {})
        if len(stored_value.keys()) < self.topx_data.get(pm.key, PluginMeasurementStorage.MAX_DIMENSIONS_PER_METRIC):
            self._persistent_storage[pm.topXKey].setdefault(pm.dimensions_keys_tuple, []).append(pm)
            self._total_storage_size += 1
            self._flat_storage.append(pm)
            return True
        self._overflow_info.add(pm.key)
        return False

    def items(self) -> typing.List[PluginMeasurement]:
        return self._flat_storage

    def load(self, pm: PluginMeasurement) -> PluginMeasurement:
        return None if len(self._persistent_storage.get(pm.topXKey, {}).get(pm.dimensions_keys_tuple, [])) is 0 \
            else self._persistent_storage[pm.topXKey][pm.dimensions_keys_tuple][0]

    @property
    def size(self) -> int:
        return self._total_storage_size

    def flush(self):
        return self._flat_storage

    def clear_results_only(self):
        self._total_storage_size = 0
        self._flat_storage.clear()

    @property
    def topx_overflow(self):
        return len(self._overflow_info) > 0

    @property
    def overflow_info(self) -> typing.Iterable[str]:
        return self._overflow_info

