"""
Data reporting API for plugins.
"""
import copy
import time
from typing import Dict, List, Tuple

from ruxit.api.data import BaseMetric, PluginMeasurementList, PluginMeasurement, PluginProperty, \
    PluginMeasurementStatCounter, PluginStateMetric, MEAttribute, PluginMeasurementStorage
from ruxit.api.events import Event, EventMetadataKey, EventType, EventMetadata, CorrelationEvent, \
    check_custom_properties
from ruxit.api.selectors import ExplicitPgiSelector, EntityType, FromPluginSelector, SelectorBase
from ruxit.utils.firewall import InternalAPI


class ResultsBuilder:
    """
    Class storing data gathered by plugins. An instance of this class is associated with each plugin instance.

    The builder can store intermittent results and perform calculations on them when they need to be sent away. Those
    include computing the difference between subsequent measurement, providing per second rates etc.

    Measurements can be passed in the form of manually created :class:`~ruxit.api.data.PluginMeasurement` objects (via
    add_*_result methods), or via absolute/relative/per_second methods which construct the measurement instances
    themselves.
    """

    _PLUGIN_MEASUREMENTS_LIMIT = 100000  # it includes dimensions
    _PLUGIN_EVENTS_LIMIT = 100
    _PLUGIN_PROPERTY_LIMIT = 20
    _PLUGIN_GROUP_PROPERTY_LIMIT = 20
    _PLUGIN_PROPERTY_NAME_LEN_LIMIT = 100
    _PLUGIN_PROPERTY_VAL_LEN_LIMIT = 200

    def __init__(self, logger, external_api, topx_data: Dict[str, int] = {}):
        self.logger = logger
        # external_api for debug flags only
        self.external_api = external_api
        self.topx_data = topx_data

        self.old_relative_results = {}
        self.topx_data = topx_data
        self.old_relative_top_results = PluginMeasurementStorage(self.topx_data)
        self.relative_top_results = PluginMeasurementStorage(self.topx_data)
        self.old_per_second_results = {}
        self.per_second_top_results = PluginMeasurementStorage(self.topx_data)
        self.old_per_second_top_results = PluginMeasurementStorage(self.topx_data)
        self.absolute_top_results = PluginMeasurementStorage(self.topx_data)
        self.__reset_result()
        self._clear_after_flush()
        self.__event_check_stack = 3
        self.topx_overflow_info: set[str] = set()

    # set depth of stack for event log
    # if event is not created it point with plugin fails
    @property
    def event_check_stack(self) -> int:
        """ DT_IGNORE """
        return self.__event_check_stack;

    # set depth of stack for event log
    # if event is not created it point with plugin fails
    @event_check_stack.setter
    def event_check_stack(self, value: int):
        self.__event_check_stack = value

    def __store_old_data(self):
        self.old_relative_top_results = self.relative_top_results
        self.old_per_second_top_results = self.per_second_top_results
        self.relative_top_results = PluginMeasurementStorage(self.topx_data)
        self.per_second_top_results = PluginMeasurementStorage(self.topx_data)

    def __reset_result(self):
        self.relative_top_results = PluginMeasurementStorage(self.relative_top_results.topx_data)
        self.per_second_top_results = PluginMeasurementStorage(self.per_second_top_results.topx_data)
        self.absolute_top_results = PluginMeasurementStorage(self.absolute_top_results.topx_data)

    def _clear_flushed_results(self):
        self.relative_top_results.clear_results_only()
        self.per_second_top_results.clear_results_only()
        self.absolute_top_results.clear_results_only()

    def _clear_after_flush(self):
        self.events = []
        self.plugin_properties = []
        self._timestamp = None

    # call reset_result in case of an exception to clear up incomplete results
    def reset_result(self):
        """
        DT_IGNORE
        :return:
        """
        self.__reset_result()
        self._clear_after_flush()
        self.old_relative_results = {}
        self.old_relative_top_results = PluginMeasurementStorage()
        self.old_per_second_top_results = PluginMeasurementStorage()

    @staticmethod
    def _pm_to_key(pm):
        return pm.key, tuple(pm.dimensions.items()), pm.entity_selector

    @staticmethod
    def _check_measurement_type(plugin_measurement):
        if not isinstance(plugin_measurement, BaseMetric):
            raise TypeError(
                "Each measurement should be an instance of BaseMetric, got %s instead" % type(plugin_measurement))

    @property
    def PLUGIN_MEASUREMENTS_LIMIT(self) -> int:
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentMeasurementsLimitNative", ResultsBuilder._PLUGIN_MEASUREMENTS_LIMIT)

    @property
    def PLUGIN_EVENTS_LIMIT(self) -> int:
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentEventsLimitNative", ResultsBuilder._PLUGIN_EVENTS_LIMIT)

    @property
    def PLUGIN_PROPERTY_LIMIT(self) -> int:
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentPropertyLimitNative", ResultsBuilder._PLUGIN_PROPERTY_LIMIT)

    @property
    def PLUGIN_GROUP_PROPERTY_LIMIT(self) -> int:
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentGroupPropertyLimitNative", ResultsBuilder._PLUGIN_GROUP_PROPERTY_LIMIT)

    @property
    def PLUGIN_PROPERTY_NAME_LEN_LIMIT(self) -> int:
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentPropertyNameLimitNative", ResultsBuilder._PLUGIN_PROPERTY_NAME_LEN_LIMIT)

    @property
    def PLUGIN_PROPERTY_VAL_LEN_LIMIT(self):
        """ DT_IGNORE """
        return self.external_api.get_int_debug_flag(
            "debugPluginAgentPropertyValueLimitNative", ResultsBuilder._PLUGIN_PROPERTY_VAL_LEN_LIMIT)

    def _createpm(self, **kwargs):
        if 'entity_id' in kwargs:
            if 'entity_selector' in kwargs:
                raise ValueError("entity_id and entity_selector are mutually exclusive options")
            entity_id = kwargs.pop('entity_id')
            if 'entity_type' in kwargs:
                if not isinstance(kwargs.get('entity_type'), EntityType):
                    raise ValueError("entity_type must be instance of EntityType")
                entity_type = kwargs.pop('entity_type')
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id, me_type=entity_type)
            else:
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id)
        return PluginMeasurement(**kwargs)

    def _createpsm(self, **kwargs):
        if 'entity_id' in kwargs:
            if 'entity_selector' in kwargs:
                raise ValueError("entity_id and entity_selector are mutually exclusive options")
            entity_id = kwargs.pop('entity_id')
            if 'entity_type' in kwargs:
                if not isinstance(kwargs.get('entity_type'), EntityType):
                    raise ValueError("entity_type must be instance of EntityType")
                entity_type = kwargs.pop('entity_type')
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id, me_type=entity_type)
            else:
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id)
        return PluginStateMetric(**kwargs)

    def _createpp(self, **kwargs):
        if 'entity_id' in kwargs:
            if 'entity_selector' in kwargs:
                raise ValueError("entity_id and entity_selector are mutually exclusive options")
            entity_id = kwargs.pop('entity_id')
            if 'entity_type' in kwargs:
                if not isinstance(kwargs.get('entity_type'), EntityType):
                    raise ValueError("entity_type must be instance of EntityType")
                entity_type = kwargs.pop('entity_type')
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id, me_type=entity_type)
            else:
                kwargs['entity_selector'] = ExplicitPgiSelector(pgi_id=entity_id)
        return PluginProperty(**kwargs)

    def add_relative_result(self, plugin_measurement: PluginMeasurement):
        """
        Adds a relative result. Use for metrics that increase monotonically (such as counters). After gathering the second result,
        the difference between the current and previous results is sent to the server (if it is non-negative). If there is a
        negative difference between measurements, nothing is sent.

        :param plugin_measurement: :class:`PluginMeasurement` measurement
        """
        if isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_relative_result doesn't support measurement of type PluginMeasurementStatCounter.")
        self._check_measurement_type(plugin_measurement)
        self.relative_top_results.store(plugin_measurement)

    def add_absolute_result(self, plugin_measurement):
        """
        Adds an absolute results. Absolute results are sent unmodified - no additional calculations are performed.

        :param plugin_measurement: :class:`PluginMeasurement` measurement

        """
        self._check_measurement_type(plugin_measurement)
        self.absolute_top_results.store(plugin_measurement)

    def add_absolute_stat_counter_result(self, plugin_measurement):
        """
        DT_IGNORE - because this isn't meant to be an advertised method of sending metrics.
        Adds an absolute PluginMeasurementStatCounter results. Absolute results are sent unmodified - no additional calculations are performed.

        Args:
            plugin_measurement(PluginMeasurementStatCounter): measurement

        """
        if not isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_absolute_stat_counter_result is designated for measurement of type PluginMeasurementStatCounter only.")
        self.add_absolute_result(plugin_measurement)

    def add_per_second_result(self, plugin_measurement):
        """
        Adds per-second result. Use for metrics that increase monotonically (such as counters). After gathering the second result,
        the difference between current and previous results is sent to the server (if it is non-negative). It will be
        divided by the time difference between measurements in seconds, resulting in a per-second rate. If there is a
        negative difference between measurements, nothing is sent.

        :param plugin_measurement: :class:`PluginMeasurement` measurement

        """
        if isinstance(plugin_measurement, PluginMeasurementStatCounter):
            raise TypeError(
                "Method add_per_second_result doesn't support measurement of type PluginMeasurementStatCounter.")
        self._check_measurement_type(plugin_measurement)
        self.per_second_top_results.store(plugin_measurement)

    def absolute(self, **kwargs):
        """
        Adds absolute result. :class:`ruxit.api.data.PluginMeasurement` object is constructed implicitly in the method. Keyword arguments
        correspond to :class:`ruxit.api.data.PluginMeasurement` class keyword with the addition of:

        :param entity_id: value of entity id.
        :param entity_type: :class:`EntityType` type of entity. Default: :class:`ruxit.api.selectors.EntityType.PROCESS_GROUP_INSTANCE`
        """
        _pm = self._createpm(**kwargs)
        self.add_absolute_result(_pm)

    def state_metric(self, key, value, dimensions=None,
                     entity_id=None,
                     entity_type=EntityType.PROCESS_GROUP_INSTANCE,
                     entity_selector=None):
        """
        Adds state metric. :class:`~ruxit.api.data.PluginStateMetric` object is constructed implicitly in the method.

        :param key: key of the measurement. Must be a string.
        :param value: value of the measurement. Must be convertible to float.
        :param dimensions: dimensions of the measurement. A Dictionary with string keys and string values.
        :param entity_id: value of entity id. Mutually exclusive with entity_selector.
        :param entity_type: :class:`EntityType` type of entity. Default: :class:`ruxit.api.selectors.EntityType.PROCESS_GROUP_INSTANCE`
        :param entity_selector: :class:`SelectorBase` explicit selector of the entity. Mutually exclusive with entity_id.
        """
        entity_selector = self._resolve_entity_selector(entity_id, entity_type, entity_selector)
        self.add_absolute_result(PluginStateMetric(key, value, dimensions, entity_selector))

    def report_property(self, key=None, value=None, me_attribute=MEAttribute.INTERNAL_DEBUG_PROPERTY,
                        entity_id=None,
                        entity_type=EntityType.PROCESS_GROUP_INSTANCE,
                        entity_selector=None):
        """
        Adds entity property. PluginProperty object is constructed implicitly in the method.

        :param key: key of the measurement. Must be a string.
        :param value: value of the measurement. Must be convertible to float.
        :param me_attribute: :class:`MEAttribute` ME attribute to report. Default :class:`ruxit.api.data.MEAttribute.INTERNAL_DEBUG_PROPERTY`
        :param entity_id: value of entity id. Mutually exclusive with entity_selector.
        :param entity_type: :class:`EntityType` type of entity. Default: :class:`ruxit.api.selectors.EntityType.PROCESS_GROUP_INSTANCE`
        :param entity_selector: :class:`SelectorBase`: explicit selector of the entity. Mutually exclusive with entity_id.
        """
        entity_selector = self._resolve_entity_selector(entity_id, entity_type, entity_selector)
        self.add_property(PluginProperty(key, value, entity_selector, me_attribute))

    @InternalAPI
    def add_event(self, event):
        """
        Adds a event

        :param event: :class:`Event` event
        """
        self.events.append(event)

    def relative(self, **kwargs):
        """
        Adds relative result, with PluginMeasurement object constructed implicitly. Accepts arguments identical to
        :meth:`absolute`

        """
        _pm = self._createpm(**kwargs)
        self.add_relative_result(_pm)

    def per_second(self, **kwargs):
        """
        Adds per second result, with PluginMeasurement object constructed implicitly. Accepts arguments identical to
        :meth:`absolute`
        """
        _pm = self._createpm(**kwargs)
        self.add_per_second_result(_pm)

    def add_property(self, plugin_property):
        """
        Adds a property to the results

        :param plugin_property: :class:`PluginProperty` the property.
        """
        if not isinstance(plugin_property, PluginProperty):
            raise TypeError(
                "Each property should be an instance of PluginProperty, got %s instead" % type(plugin_property))
        self.plugin_properties.append(plugin_property)

    def set_timestamp(self, timestamp):
        """
        DT_IGNORE
        Allows explicit setting of timestamp for all gathered measurements.

        :param timestamp: timestamp
        """
        self._timestamp = timestamp

    def flush_result(self, is_full=True) -> Tuple[PluginMeasurementList, List[PluginProperty], List[Event]]:
        """
        DT_IGNORE
        Prepares gathered data to be sent out to the server. Computes values for relative and per_second results.

        :return: Measurements and properties gathered during the most recent data collection period.
        """
        self.topx_overflow_info: set[str] = set()
        measurements = PluginMeasurementList(measurements=[], timestamp=self._timestamp)

        for pm in self.relative_top_results.items():
            old_pm = self.old_relative_top_results.load(pm)
            if old_pm is None:
                continue
            delta_metric = copy.copy(pm)
            value_delta = pm.value - old_pm.value
            if value_delta < 0:
                self.logger.info(
                    "Value decrease in relative result, skip reporting, new value %s, old value %s",
                    pm.value,
                    old_pm.value
                )
                continue
            delta_metric.value = value_delta
            measurements.measurements.append(delta_metric)

        for pm in self.per_second_top_results.items():
            old_pm = self.old_per_second_top_results.load(pm)
            if old_pm is None:
                continue
            value_per_second = (pm.value - old_pm.value) / (pm.measurement_time - old_pm.measurement_time)
            if value_per_second < 0:
                self.logger.info(
                    "Per second result less than 0, skip reporting, new value %s, old value %s",
                    pm.value,
                    old_pm.value
                )
                continue
            per_second = copy.copy(pm)
            per_second.value = value_per_second
            measurements.measurements.append(per_second)

        self.topx_overflow_info.update(self.absolute_top_results.overflow_info)
        self.topx_overflow_info.update(self.relative_top_results.overflow_info)
        self.topx_overflow_info.update(self.per_second_top_results.overflow_info)

        measurements.measurements.extend(self.absolute_top_results.items())

        properties = self.plugin_properties
        events = self.events

        if is_full:
            self.__store_old_data()
            self.__reset_result()
        self._clear_flushed_results()
        self._clear_after_flush()

        return measurements, properties, events

    @property
    def was_topx_overflow(self) -> bool:
        return len(self.topx_overflow_info) > 0

    @property
    def get_topx_overflow_info(self) -> str:
        return ", ".join(self.topx_overflow_info)

    def report_performance_event(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {},
                                 entity_selector=FromPluginSelector()):
        """
        Reports performance event.

        :param description: event description
        :param title: event title
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        self.events.append(
            self._create_correlation_event(type=EventType.PERFORMANCE_EVENT, description=description,
                                           title=title,
                                           properties=properties, entity_selector=entity_selector))

    def report_error_event(self, description: str = None, title: str = None,
                           properties: Dict[str, str] = {},
                           entity_selector=FromPluginSelector()):
        """
        Reports error event.

        :param description: event description
        :param title: event title
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        self.events.append(
            self._create_correlation_event(type=EventType.ERROR_EVENT, description=description,
                                           title=title,
                                           properties=properties, entity_selector=entity_selector))

    def report_availability_event(self, description: str = None, title: str = None,
                                  properties: Dict[str, str] = {},
                                  entity_selector=FromPluginSelector()):
        """
        Reports availability event.

        :param description: event description
        :param title: event title
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        self.events.append(
            self._create_correlation_event(type=EventType.AVAILABILITY_EVENT, description=description,
                                           title=title,
                                           properties=properties, entity_selector=entity_selector))

    def report_resource_contention_event(self, description: str = None, title: str = None,
                                         properties: Dict[str, str] = {},
                                         entity_selector=FromPluginSelector()):
        """
        Reports resource contention event.

        :param description: event description
        :param title: event title
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        self.events.append(
            self._create_correlation_event(type=EventType.RESOURCE_CONTENTION_EVENT,
                                           description=description,
                                           title=title,
                                           properties=properties, entity_selector=entity_selector))

    def report_custom_info_event(self, description: str = None, title: str = None,
                                 properties: Dict[str, str] = {},
                                 entity_selector=FromPluginSelector()):
        """
        Reports custom info event.

        :param description: event description
        :param title: event title
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        properties = check_custom_properties(properties, 2)
        self.events.append(Event(event_type=EventType.CUSTOM_INFO,
                                 entity_selector=entity_selector,
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DESCRIPTION, value=description),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_TITLE, value=title),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)
                                 ]))

    def report_custom_deployment_event(self,
                                       source: str = None,
                                       project: str = None,
                                       version: str = None,
                                       ci_link: str = None,
                                       remediation_action_link: str = None,
                                       deployment_name: str = None,
                                       properties: Dict[str, str] = {},
                                       entity_selector=FromPluginSelector()):
        """
        Reports custom deployment event.

        :param source: event source
        :param project: project
        :param version: event version
        :param ci_link: ci link
        :param remediation_action_link: remediation action link
        :param deployment_name: deployment name
        :param properties: deployment properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        properties = check_custom_properties(properties, 2)
        self.events.append(Event(event_type=EventType.CUSTOM_DEPLOYMENT,
                                 entity_selector=entity_selector,
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_SOURCE, value=source),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROJECT, value=project),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_VERSION, value=version),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_CI_BACK_LINK, value=ci_link),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_REMEDIATION_ACTION_LINK,
                                                   value=remediation_action_link),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DEPLOYMENT_NAME, value=deployment_name),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)
                                 ]))

    def report_custom_annotation_event(self,
                                       description: str = None,
                                       annotation_type: str = None,
                                       source: str = None,
                                       properties: Dict[str, str] = {},
                                       entity_selector=FromPluginSelector()):
        """
        Reports custom annotation event.

        :param description: event description
        :param annotation_type: annotation type
        :param source: event source
        :param properties: event properties
        :param entity_selector: selector, :class:`~ruxit.api.selectors.FromPluginSelector` by default
        """
        properties = check_custom_properties(properties, 2)
        self.events.append(Event(event_type=EventType.CUSTOM_ANNOTATION,
                                 entity_selector=entity_selector,
                                 metadata=[
                                     EventMetadata(key=EventMetadataKey.CUSTOM_DESCRIPTION, value=description),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_ANNOTATION_TYPE, value=annotation_type),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_SOURCE, value=source),
                                     EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)
                                 ]))

    def _create_correlation_event(self, **kwargs):
        properties = check_custom_properties(kwargs.get('properties'), self.event_check_stack)
        return CorrelationEvent(event_type=kwargs['type'],
                                entity_selector=kwargs['entity_selector'],
                                metadata=[
                                    EventMetadata(key=EventMetadataKey.CUSTOM_DESCRIPTION, value=kwargs['description']),
                                    EventMetadata(key=EventMetadataKey.CUSTOM_TITLE, value=kwargs['title']),
                                    EventMetadata(key=EventMetadataKey.CUSTOM_PROPERTIES, value=properties)])

    @staticmethod
    def _resolve_entity_selector(entity_id, entity_type, entity_selector):
        if entity_id is not None:
            if entity_selector is not None:
                raise ValueError("entity_id and entity_selector are mutually exclusive options")
            if entity_type is not None:
                if not isinstance(entity_type, EntityType):
                    raise ValueError("entity_type must be instance of EntityType")
                return ExplicitPgiSelector(pgi_id=entity_id, me_type=entity_type)
            else:
                return ExplicitPgiSelector(pgi_id=entity_id)
        elif entity_selector is None:
            return FromPluginSelector()
        if not isinstance(entity_selector, SelectorBase.__args__):
            raise ValueError("entity_selector must be instance of SelectorBase")
        return entity_selector
