import sys
import os
import logging
from pathlib import Path

log = logging.getLogger(__name__)


def get_default_installation_dir():
    """
    Returns default installation directory for Osagent. It should return
    C:/ProgramFiles(x86)/dynatrace/oneagent for Windows and /opt/dynatrace/oneagent for Linux

    :rtype: str
    :return: remote plugin agent installation directory
    """
    if sys.platform == "win32":
        install_path = os.path.expandvars(r'%PROGRAMW6432%\dynatrace\oneagent')
        conf_path = os.path.expandvars(r'%programdata%\dynatrace\oneagent\agent\config\ruxitagentproc.conf')
    else:
        install_path = '/opt/dynatrace/oneagent'
        conf_path = '/var/lib/dynatrace/oneagent/agent/config/ruxitagentproc.conf'
    try:
        with open (conf_path, 'r') as conf_file:
            prefix = 'libraryPath64 '
            for line in conf_file:
                if line.startswith(prefix):
                    lib_path = Path(line[len(prefix)+1:-1])
                    install_path = lib_path.parent.parent.parent.parent
                    break
    except OSError as e:
        pass
    logging.debug("Setting installation root dir to %s", install_path)
    return install_path


def get_default_config_persistence_dir():
    """
    Returns default config persistence for Osagent where all files created by agent will be stored. It
    should return C:/ProgramData/dynatrace/oneagent/agent/conf for Windows and
    /opt/dynatrace/oneagent/agent/conf for Linux

    :rtype: str
    :return: remote plugin agent storage directory
    """
    if sys.platform == "win32":
        ret = os.path.join(os.environ["programdata"], "dynatrace", "oneagent", "agent", "config")
    else:
        ret = os.path.join(os.path.sep, "var","lib","dynatrace","oneagent","agent","config")
    logging.debug("Setting persistence config dir to %s", ret)
    return ret