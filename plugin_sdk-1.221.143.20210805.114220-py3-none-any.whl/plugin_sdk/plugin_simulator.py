import argparse, collections, json, logging, os, sys
import unittest, unittest.mock
import itertools, operator, time, datetime, colorama, pprint
import ruxit.plugin_loop
import plugin_sdk.sdk_version
import plugin_sdk.plugin_upload
import ruxit.plugin_state_machine
from colorama import Fore, Style
from ruxit.package_utils.plugin_updater import PluginInfo
from ruxit.plugin_state_machine import PluginStateGroups
from ruxit.plugin_status_reporter import PluginState

# new
from ruxit.plugin_state_machine import PluginEngine
from ruxit.platform.platform_api import PluginConfig
from ruxit.config_utils import create_config
from ruxit.select_plugins import PluginSelector
from ruxit.entity_resolver import EntityResolver
from ruxit.remote.platform_remote import (
    RemoteAPI,
    RemoteActivationContext,
    RemoteEntityResolver,
    RemotePluginConfigInfo,
)
from ruxit.remote.remote_plugin_engine import RemotePluginEngine
from ruxit.platform.platform_embedded import EmbeddedAPI
from .python_check import python_version_compatible
from plugin_sdk import validator

logger = logging.getLogger(__name__)

is_first_run = True


class MockWithCallTimestamps(unittest.mock.Mock):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.call_timetamps = []

    def _mock_call(self, *args, **kwargs):
        self.call_timetamps.append(datetime.datetime.now())
        return super()._mock_call(self, *args, **kwargs)


NativePluginConfigInfo = collections.namedtuple(
    "NativePluginConfigInfo", ["name", "properties", "fast_id", "enabled"]
)

_ProcessSnapshotBase = collections.namedtuple(
    "_ProcessSnapshotBase", ["entries", "host_id", "containers"]
)


class _ProcessSnapshot(_ProcessSnapshotBase):
    def __new__(cls, **kwargs):
        kwargs.setdefault("host_id", 1)
        kwargs.setdefault("entries", [])
        kwargs.setdefault("containers", [])
        return super().__new__(cls, **kwargs)

    @classmethod
    def from_json(cls, **kwargs):
        kwargs["entries"] = [
            _ProcessSnapshotEntry.from_json(**entry_json)
            for entry_json in kwargs.pop("entries", [])
        ]
        return cls.__new__(cls, **kwargs)


_ProcessSnapshotEntryBase = collections.namedtuple(
    "ProcessSnapshotEntryBase",
    [
        "process_type",
        "group_instance_id",
        "group_id",
        "node_id",
        "group_name",
        "processes",
        "properties",
    ],
)


class _ProcessSnapshotEntry(_ProcessSnapshotEntryBase):
    def __new__(cls, **kwargs):
        kwargs.setdefault("process_type", 0)
        kwargs.setdefault("group_instance_id", 1)
        kwargs.setdefault("group_id", 1)
        kwargs.setdefault("node_id", 1)
        kwargs.setdefault("group_name", "group_name")
        kwargs.setdefault("processes", [])
        kwargs.setdefault("properties", {})
        return super().__new__(cls, **kwargs)

    @classmethod
    def from_json(cls, **kwargs):
        kwargs["processes"] = [
            _ProcessInfo.from_json(**pinfo_json)
            for pinfo_json in kwargs.pop("processes", [])
        ]
        return cls.__new__(cls, **kwargs)


_ProcessInfoBase = collections.namedtuple(
    "_ProcessInfoBase", ["pid", "process_name", "properties"]
)


class _ProcessInfo(_ProcessInfoBase):
    def __new__(cls, **kwargs):
        kwargs.setdefault("pid", 1000)
        kwargs.setdefault("process_name", "process_name")
        kwargs.setdefault("properties", {})
        return super().__new__(cls, **kwargs)

    @classmethod
    def from_json(cls, **kwargs):
        return cls.__new__(cls, **kwargs)


def setup_logging(verbose=False):
    log_format = "%(asctime)-15s [%(levelname)s] - %(thread)s(%(threadName)s) - [%(funcName)s] %(message)s"
    level = logging.DEBUG if verbose else logging.DEBUG
    logging.basicConfig(
        level=level,
        format=log_format,
        handlers=[logging.StreamHandler(stream=sys.stderr)],
    )


def md5_hash_mock(input_bytes):
    import hashlib

    h = hashlib.md5()
    h.update((2).to_bytes(8, byteorder="little"))
    h.update(input_bytes)
    return int(h.hexdigest()[:16], 16)

def validate_plugin(plugin_path):
    if not plugin_path.endswith("plugin.json"):
        plugin_path = os.path.join(plugin_path, "plugin.json")
    try:
        validator._validate_plugin_json(plugin_path)
    except Exception:
        logger.error(
            "Plugin validation failed", exc_info=1
        )
        sys.exit(-1)



def main():
    args = parse_args(sys.argv[1:])
    _main(args)


def _main(args):
    logging.basicConfig(
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler("ruxitagent_remotepluginagent.log"),
        ]
    )
    args.plugin_dir == os.path.abspath(args.plugin_dir)
    run_simulator(
        args.plugin_dir,
        args.snapshot or args.plugin_dir,
        args.properties or args.plugin_dir,
        args.interval,
        args.verbose,
    )

def parse_args(cmd_args):
    # note the command help message is referenced in documentation.
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-p", "--plugin_dir", default=os.getcwd(), help="plugin directory path"
    )
    parser.add_argument(
        "-v", "--verbose", help="increase verbosity", action="store_true"
    )
    parser.add_argument(
        "-n",
        "--snapshot",
        help="path to snapshot file (PLUGIN_DIR/simulator_snapshot.json by default)",
    )
    parser.add_argument(
        "-r",
        "--properties",
        help="path to properties file (PLUGIN_DIR/properties.json by default)",
    )
    parser.add_argument(
        "-i",
        "--interval",
        type=int,
        help="set the interval between plugin measurements (default: 60 seconds)",
    )

    __version__ = plugin_sdk.sdk_version.get_version()
    parser.add_argument(
        "--version",
        action="version",
        help="show program's version and exit",
        version=("{name} {version}".format(name=__package__, version=__version__)),
    )
    return parser.parse_args(cmd_args)

status_mock = MockWithCallTimestamps()
should_quit = False
log_path = None

def quit_iterator():
    while True:
        yield not should_quit

def build_hash_data(*args):
    input_bytes = b""
    # combine everything passed to the function
    for item in args:
        if isinstance(item, int):
            input_bytes += item.to_bytes(8, byteorder="big")
        elif isinstance(item, str):
            encoded = item.encode("utf-8")
            input_bytes += encoded
            input_bytes += len(encoded).to_bytes(4, byteorder="big")
    return input_bytes


def run_simulator(plugin_path, snapshot_path, properties_path, measure_interval=0, verbose=False):
    
    setup_logging(verbose)
    if not python_version_compatible():
        exit(1)
    plugin_info = get_plugin_info(plugin_path)
    validate_plugin(plugin_path)
    plugin_properties = get_plugin_properties(properties_path)
    activation = plugin_info.json_data.get("source", {}).get("activation", None)
    snapshot = _ProcessSnapshot()
    if not plugin_sdk.plugin_upload.is_remote(plugin_info.reported_name):
        snapshot = get_snapshot(snapshot_path)
    plugin_metadata = [get_plugin_metadata(plugin_path)]
    if measure_interval:
        logger.info("measure interval set")
        ruxit.plugin_state_machine.PluginEngine.measure_interval_seconds = (
            measure_interval
        )

    latest_configs = {
        plugin_info.reported_name: NativePluginConfigInfo(
            name=plugin_info.reported_name,
            fast_id=(),
            enabled=True,
            properties=plugin_properties
        )
    }

    cfg, enabled, complete, fast_id = create_config(plugin_info, latest_configs, logger)
    plugin_config = PluginConfig(cfg, fast_id, enabled)

    external_api = unittest.mock.Mock()
    external_api.plugins_enabled = lambda: True
    external_api.get_latest_snapshot = lambda: snapshot
    external_api.get_latest_configs = lambda: latest_configs
    external_api.is_debug_logging_enabled = lambda: verbose
    external_api.should_pause = lambda: False
    external_api.resolve_conflicts_flag = lambda: True
    external_api.get_timestamp = lambda: time.time()*1000.0
    external_api.get_cluster_timestamp = lambda: time.time()*1000.0
    external_api.get_int_debug_flag = lambda name, default: default
    external_api.get_bool_debug_flag = lambda name, default: default
    external_api.get_str_debug_flag = lambda name, default: default
    external_api.get_log_path = lambda: log_path or plugin_path 
    external_api.get_install_path = lambda: log_path or plugin_path 
    external_api.murmur_hash_2_64 = lambda data: md5_hash_mock(data)
    external_api.murmur_hash_3_64 = lambda data: md5_hash_mock(data)
    external_api.getCustomDeviceGroupMELongId = lambda namespace, identifier: md5_hash_mock(
        build_hash_data(namespace, identifier)
    )
    external_api.getCustomDeviceMELongId = lambda group_id, identifier: md5_hash_mock(
        build_hash_data(group_id, identifier)
    )
    external_api.get_working_tenant = unittest.mock.Mock(return_value="Tenant1234")

    report_results_mock = MockWithCallTimestamps()

    external_api.report_plugins_status = status_mock
    external_api.get_cpu_usage = lambda: 10.5
    external_api.get_mem_usage = lambda: 1000
    external_api.get_agent_version = lambda: plugin_sdk.sdk_version.get_version()

    plugin_selector = PluginSelector()
    platform_api = unittest.mock.Mock()
    platform_api.entity_resolver = EntityResolver()
    platform_api.entity_resolver.set_snapshot(snapshot)
    platform_api.external_api = external_api
    platform_api.select_plugins = lambda plugin_engines, plugin_metadata: plugin_selector.select_plugins(
        snapshot, plugin_metadata, plugin_engines, logger
    )
    platform_api.get_plugin_config = (
        lambda plugin_engine, latest_plugin_infos: plugin_config
    )
    platform_api._update_latest_snapshot = lambda: False
    platform_api.additional_report_step = lambda plugin_engine: False
    platform_api.get_support_alert_creator = lambda: EmbeddedAPI(
        platform_api
    ).get_support_alert_creator()
    platform_api.get_not_existing_plugins = lambda plugins : []

    if not plugin_sdk.plugin_upload.is_remote(plugin_info.reported_name):
        platform_api.create_engine = lambda plugin_info, activation_context: PluginEngine(
            external_api=external_api,
            entity_resolver=platform_api.entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context,
        )
        platform_api.is_local = True
    else:
        remoteAPI = RemoteAPI(platform_api)
        remote_plugin_config = {}
        remote_plugin_config[123] = RemotePluginConfigInfo(
            plugin_name=plugin_info.reported_name,
            config_id=123,
            plugin_instance_config={"instance_cfg": "simulator"},
            fast_id=None,
            fast_checked=False,
            enabled=True,
            is_new=True,
            endpoint_name="Test configuration"
        )
        remoteAPI._latest_plugin_configs = remote_plugin_config
        platform_api.data_update = data_update_mock

        ac = RemoteActivationContext(config_id=1, 
                                     endpoint_name="Test configuration", 
                                     properties=plugin_config,
                                     enabled=True)
        pe = platform_api.create_engine(plugin_info, ac)
        plugin_engines = []
        plugin_engines.append(pe)
        platform_api.select_plugins = lambda plugin_engines, plugin_metadata: remoteAPI.select_plugins(
            plugin_engines, plugin_metadata
        )
        platform_api.remote_entity_resolver = RemoteEntityResolver()

        platform_api.create_engine = lambda plugin_info, activation_context: RemotePluginEngine(
            remote_api=platform_api,
            external_api=external_api,
            entity_resolver=platform_api.remote_entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context,
        )
        remoteAPI._plugin_topology_reporter._external_api.get_int_debug_flag = (
            lambda name, default: default
        )
        platform_api.additional_report_step = lambda plugin_engine: remoteAPI.additional_report_step(
            plugin_engine
        )
        platform_api.is_local = False

    try:
        ruxit.plugin_loop.main(
            stop_strategy= quit_iterator(),
            report_results_strategy=report_results_mock,
            get_metadata_strategy=lambda: plugin_metadata,
            platform_api=platform_api,
            num_python_threads=4
        )
    except KeyboardInterrupt:
        logger.warn("Plugin simulator was stopped with a Keyboard interrupt")
    except Exception:
        logger.error(
            "Plugin simulator was stopped with unexpected exception", exc_info=1
        )
    finally:
        results = _get_results(report_results_mock)
        statuses = get_statuses(status_mock)
        all_events = list(itertools.chain(results, statuses))
        all_events.sort(key=operator.attrgetter("timestamp"))

        try:
            colorama.init()
            print(Fore.GREEN + "Plugin simulator summary:" + Style.RESET_ALL)
            for event in all_events:
                event.print()
        finally:
            colorama.deinit()


def data_update_mock():
    global is_first_run
    tmp = is_first_run
    is_first_run = False
    return True if tmp else False


def get_plugin_info(plugin_path):
    if not plugin_path.endswith("plugin.json"):
        plugin_path = os.path.join(plugin_path, "plugin.json")
    try:
        with open(plugin_path) as f:
            return PluginInfo(json.load(f), os.path.dirname(plugin_path))
    except json.JSONDecodeError as error:
        logger.error("Unable to decode plugin.json file. %s", error)
        sys.exit(-1)
    except FileNotFoundError:
        logger.error("Unable to find plugin.json file", exc_info=1,)
        sys.exit(-1)


def get_plugin_properties(properties_path):
    if os.path.isdir(properties_path):
        properties_path = os.path.join(properties_path, "properties.json")
    try:
        with open(properties_path) as f:
            return json.load(f)
    except json.JSONDecodeError as error:
        logger.warning(
            "Unable to decode plugin configuration file, assuming emtpy config. %s",
            error
        )
    except FileNotFoundError:
        logger.warning(
            "Unable to find plugin configuration file, assuming emtpy config",
            exc_info=1,
        )
        return {}


def get_snapshot(snapshot_path):
    if os.path.isdir(snapshot_path):
        snapshot_path = os.path.join(snapshot_path, "simulator_snapshot.json")
    with open(snapshot_path) as f:
        return _ProcessSnapshot.from_json(**json.load(f))


def get_plugin_metadata(plugin_path):
    if not plugin_path.endswith("plugin.json"):
        plugin_path = os.path.join(plugin_path, "plugin.json")
    with open(plugin_path) as f:
        return os.path.dirname(plugin_path), f.read()


class MeasurementsEvent:
    def __init__(self, timestamp, measurements):
        self.timestamp = timestamp
        self.measurements = measurements

    def print(self):
        _ts = datetime.datetime.strftime(self.timestamp, "%H:%M:%S")
        print(Fore.GREEN, end="")
        print("At %s reported measurements:" % _ts)
        print(Style.RESET_ALL, end="")
        pprint.pprint(self.measurements)


class PropertiesEvent:
    def __init__(self, timestamp, properties):
        self.timestamp = timestamp
        self.properties = properties

    def print(self):
        _ts = datetime.datetime.strftime(self.timestamp, "%H:%M:%S")
        print(Fore.GREEN, end="")
        print("At %s reported properties:" % _ts)
        print(Style.RESET_ALL, end="")
        pprint.pprint(dict(self.properties))


class EventsEvent:
    def __init__(self, timestamp, events):
        self.timestamp = timestamp
        self.events = events

    def print(self):
        _ts = datetime.datetime.strftime(self.timestamp, "%H:%M:%S")
        print(Fore.GREEN, end="")
        print("At %s reported events:" % _ts)
        print(Style.RESET_ALL, end="")
        pprint.pprint(self.events)


def _get_results(results_mock):
    # indices explanation
    # [1] - mock_call element from timestamp, mock_call, status tuple
    # [1][1] - args tuple of mock call
    # [1][1][1] - second arg of call (first is self) - PluginMeasurementsList object
    # [1][1][2] - third arg of call (first is self) - reported properties
    # [1][1][3] - third arg of call (first is self) - event from plugin
    all_results = zip(results_mock.call_timetamps, results_mock.mock_calls)

    for m in all_results:
        yield MeasurementsEvent(m[0], m[1][1][1].measurements)
        if m[1][1][2]:
            yield PropertiesEvent(m[0], m[1][1][2])
        if m[1][1][3]:
            yield EventsEvent(m[0], m[1][1][3])


class StatusEvent:
    def __init__(self, timestamp, status):
        self.timestamp = timestamp
        self.status = status

    def print(self):
        _ts = datetime.datetime.strftime(self.timestamp, "%H:%M:%S")
        if PluginStateGroups.is_error(PluginState(self.status.state)):
            print(Fore.RED, end="")
        elif PluginStateGroups.is_fine(PluginState(self.status.state)):
            print(Fore.GREEN, end="")
        else:
            print(Fore.YELLOW, end="")
        print("At %s reported status: %s" % (_ts, self.status.state))
        if self.status.description:
            print("Status details:")
            print(self.status.description)
        print(Style.RESET_ALL, end="")


def get_statuses(status_mock):
    # [1][1][1] explanation
    # [1] - mock_call element from timestamp, mock_call, status tuple
    # [1][1] - args tuple of mock call
    # [1][1][1] - second arg of call (first is self) - list of changed statuses
    # [1][1][1][0] - the first changed status... which is the one we're after
    statuses = zip(
        status_mock.call_timetamps, status_mock.mock_calls, itertools.repeat("status")
    )
    statuses = [status for status in statuses if status[1][1][1]]
    statuses_no_dup = []
    for status_mock_data in statuses:
        current_status = status_mock_data[1][1][1]
        if statuses_no_dup == [] or statuses_no_dup[-1][1][1][1] != current_status:
            statuses_no_dup.append(status_mock_data)
    return (StatusEvent(st[0], st[1][1][1][0]) for st in statuses_no_dup)


if __name__ == "__main__":
    main()
