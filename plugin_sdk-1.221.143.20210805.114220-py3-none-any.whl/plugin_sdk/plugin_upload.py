import argparse
import json
import logging
import os
import re
import sys

import requests

import ruxit.tools.plugin_schema as schema
from plugin_sdk.default_dir_provider import DefaultDirProvider

logging.basicConfig(stream=sys.stderr, format="%(message)s", level=logging.INFO)
logger = logging.getLogger(__package__)
requests_log = logging.getLogger("requests")


def _get_dir_provider(remote):
    dir_provider = DefaultDirProvider(remote)
    return dir_provider


def main():
    parsed_args = None
    try:
        parsed_args = parse_args(sys.argv[1:])
        if parsed_args.verbose:
            logger.setLevel(logging.DEBUG)
            requests_log.setLevel(logging.DEBUG)
        main_body(
            parsed_args.plugin_zip,
            parsed_args.server,
            parsed_args.token,
            parsed_args.token_file,
            parsed_args.no_cert_ver,
        )
    except Exception as ex:
        logger.error("Error occured: %s", ex)
        if parsed_args and parsed_args.verbose:
            logger.exception("Error details:")
        if str(ex).find("CERTIFICATE_VERIFY_FAILED") != -1:
            logger.info(
                "You can try to execute script with --no_cert_ver, to disable ssl certificate verification"
            )
        sys.exit(1)


def is_remote(plugin_name):
    # Zip name is generated from plugin name so it should have "remote" entry in zip-name
    if plugin_name is None : return False
    words = os.path.basename(plugin_name).split(".")
    return False if len(words) < 2 else words[1] == "remote"

def main_body(plugin_zip, server, token, token_file, no_cert_ver):
    logger.debug("plugin upload script starts")
    zip_file = _get_zip_filename(plugin_zip)
    server_names = get_server_names(is_remote(zip_file), server)
    token = get_token(is_remote(zip_file), token, token_file)

    parameter_checks = { lambda: zip_file is None : "plugin zip file",
                         lambda: len(server_names) == 0 : "server upload endpoint",
                         lambda: token is None : "token"}
    wrong_parameter = next((message for p, message in parameter_checks.items() if p()), None)
    if wrong_parameter is not None:
        logger.info(f"{wrong_parameter} is missing")
        return False;

    headers = {"Authorization": "Api-Token " + token}
    valid_responses = {200, 201, 202}
    for server_url in server_names:
        logger.info("Attempting to send plugin to server %s", server_url)
        server_address = _create_full_api_url(server_url)
        try:
            files = {"file": open(zip_file, "rb")}
            response = requests.post(
                server_address, headers=headers, files=files, verify= not no_cert_ver
            )
        except requests.exceptions.RequestException as e:
            logger.info(
                "Unable to establish connection with server %s: %s", server_address, e
            )
            continue

        if response.status_code in valid_responses:
            if len(response.text) > 0:
                try:
                    json_data = json.loads(response.text)
                    if type(json_data["id"]) is not str:
                        raise Exception("wrong id of uploaded plugin")
                except Exception:
                    logger.info(f"The server endpoint {server_url} is not designed for plugin upload")
                    logger.debug(f"Server response; {response.text}")
                    continue
            logger.info("plugin has been uploaded successfully")
            logger.debug(
                "server %s returned status code: %d %s",
                server_address,
                response.status_code,
                response.text,
            )
            return True
        else:
            logger.info(
                "server %s returned status code: %d %s",
                server_address,
                response.status_code,
                response.text,
            )
            if response.status_code == 400:
                logger.info(
                    "Please execute oneagent_verify_plugin before upload to validate plugin.json against the schema"
                )
                return False
    return False


def _read_plugin_name_from_json(plugin_json_path):
    logger.debug("Checking plugin metadata: %s", plugin_json_path)
    try:
        with open(plugin_json_path, "r") as fp:
            json_data = json.load(fp)
            return json_data["name"]
    except Exception as ex:
        logger.exception(
            "Error %s when parsing plugin.json file: %s", ex, plugin_json_path
        )
    return None


def _get_zip_filename(plugin_zip):
    if plugin_zip is None:
        plugin_name = _read_plugin_name_from_json(
            os.path.join(os.getcwd(), "plugin.json")
        )
        plugin_dev_dir = _get_dir_provider(
            is_remote(plugin_name)
        ).get_default_target_root()
        if plugin_name is not None and plugin_name != "":
            plugin_zip = os.path.join(plugin_dev_dir, plugin_name + ".zip")
    else:
        if not re.compile(schema.CUSTOM_PLUGIN_NAME).match(
            plugin_zip.split(os.path.sep)[-1]
        ):
            raise Exception(
                "Plugin zip name should match: %s" % schema.CUSTOM_PLUGIN_NAME
            )
    logger.debug("plugin zip filename: %s", plugin_zip)
    return plugin_zip


def get_server_names(remote, server):
    if server is not None: return [server]

    base_path = _get_dir_provider(remote).get_default_config_persistence_dir()
    config_file_path = os.path.join(base_path, "plugin_sdk.conf")
    try:
        with open(config_file_path, "r") as f:
            content = f.readlines()
    except OSError as oserror:
        logger.info(
            "Could not read file %s: %s - Neither OneAgent nor Remote Plugin Module is detected", config_file_path, oserror.strerror
        )
        return []
    except Exception as ex:
        logger.info("Reading file: %s exception %s.", config_file_path, ex)
        return []
    for line in content:
        line = line.strip()
        if line.startswith("pluginUploadUrls "):
            urls = line.split("pluginUploadUrls ")[1]
            return [url for url in urls.split(";") if url]
    logger.info(
        "Error when parsing %s file: file does not contain server address",
        config_file_path,
    )
    return []


def _create_full_api_url(server_url):
    if not server_url.endswith("/"):
        server_url += "/"
    return server_url


def get_token(remote, token, token_file):
    if token is not None:
        return token
    if token_file is None:
        token_file = os.environ.get("ONEAGENT_PLUGIN_UPLOAD_TOKEN")
    if token_file is None:
        token_file = os.path.join(
            _get_dir_provider(remote).get_default_conf_dir(), "plugin_upload.token"
        )
    if not os.path.isfile(token_file):
        logger.info(
            'could not find token file - launch "oneagent_upload_plugin --help" to get more information'
        )
        return None
    logger.debug("reading token from file %s", token_file)
    with open(token_file) as f:
        token = f.read()
        token = token.strip()
        logger.debug("token found in file: %s", token)
        return token


def parse_args(cmd_args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-p",
        "--plugin_zip",
        help="plugin zip path (default location of oneagent_build_plugin is taken by default)",
    )
    parser.add_argument(
        "-v", "--verbose", help="increase verbosity", action="store_true"
    )
    parser.add_argument(
        "--no_cert_ver",
        help="turn off ssl certificate verification",
        action="store_true",
    )
    parser.add_argument(
        "-s",
        "--server",
        help="server address (taken from oneagent configuration file by default)",
    )
    parser.add_argument(
        "-t",
        "--token",
        help="set the authentication token (token file is used if token is not set)",
    )
    rem_path = _get_dir_provider(True).get_default_conf_dir()
    local_path = _get_dir_provider(False).get_default_conf_dir()
    parser.add_argument(
        "-T",
        "--token_file",
        help="set the authentication token file (by default env variable ONEAGENT_PLUGIN_UPLOAD_TOKEN, or plugin_upload.token from configuration directory, which is: " + rem_path + " for remote plugin or: " + local_path + " for local plugin, if env variable is not specified)",
    )
    return parser.parse_args(cmd_args)


if __name__ == "__main__":
    main()
